see docs/source/README.txt for more details
